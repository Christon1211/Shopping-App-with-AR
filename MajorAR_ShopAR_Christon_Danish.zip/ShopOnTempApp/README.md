Shopping AR App

By Christon Andrew D'Souza & Danish Ilias Shaikh

Faculty Guide: Ms. Lipsa Sadath

Done at Amity University Dubai


