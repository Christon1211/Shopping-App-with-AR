package hackon.lifetime.shopon

import androidx.appcompat.app.AppCompatActivity
//import android.os.Bundle

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.Toast
//import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import com.google.api.client.extensions.android.http.AndroidHttp
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
//import com.google.api.client.json.gson.GsonFactory
import com.google.api.services.drive.Drive
import com.google.api.services.drive.DriveScopes

private const val REQUEST_CODE_SIGN_IN = 1
private const val REQUEST_CODE_OPEN_DOCUMENT = 2
private const val TAG = "SaminantActivity"
var account: GoogleSignInAccount? = null

class LoginActivity : AppCompatActivity() ,View.OnClickListener{
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        findViewById<Button>(R.id.btnLoginWithGoogle).setOnClickListener(this)
    }

    override fun onClick(view: View?) {
        when(view?.id){
            R.id.btnLoginWithGoogle->{
                // do some work here
                GoogleSignIn()
            }
        }
    }


    fun GoogleSignIn() {
        if (!isUserSignedIn()) {
            Toast.makeText(this, "Already LoggedIn", Toast.LENGTH_SHORT).show()
            //Toast.makeText(this, account.getEmail(), Toast.LENGTH_SHORT).show();
            //return;
        }
        try {
            val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .requestProfile()
                .requestScopes(Scope(DriveScopes.DRIVE))
                .requestIdToken("936957403421-m8ulvp3nqv27ehr0p542apangp5hrpkq.apps.googleusercontent.com")
                .build()
            val mGoogleSignInClient = GoogleSignIn.getClient(this, gso)
            val signInIntent = mGoogleSignInClient.signInIntent
            startActivityForResult(signInIntent, REQUEST_CODE_SIGN_IN)
        } catch (ex: Exception) {
        }
    }

    fun isUserSignedIn(): Boolean {
        account = GoogleSignIn.getLastSignedInAccount(this)
        return account != null
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, resultData: Intent?) {
        when (requestCode) {
            REQUEST_CODE_SIGN_IN -> if (resultCode == Activity.RESULT_OK && resultData != null) {
                handleSignInResult(resultData)
            }else{
                //Toast.makeText(mContext, "this is result not ok", Toast.LENGTH_SHORT).show();
                val intent = Intent(this, MainActivity::class.java)
                //intent.putExtra("name", googleAccount.displayName)

                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
                finish()
            }
            REQUEST_CODE_OPEN_DOCUMENT -> if (resultCode == Activity.RESULT_OK && resultData != null) {
                val uri: Uri? = resultData.data
                if (uri != null) {
                    //openFileFromFilePicker(uri);
                }
            }
        }
        super.onActivityResult(requestCode, resultCode, resultData)
    }

    private fun handleSignInResult(result: Intent) {
        GoogleSignIn.getSignedInAccountFromIntent(result)
            .addOnSuccessListener { googleAccount: GoogleSignInAccount ->
                Log.d(TAG, "Signed in as " + googleAccount.email)
                Toast.makeText(this, googleAccount.displayName, Toast.LENGTH_SHORT).show()


                val intent = Intent(this, MainActivity::class.java)
                intent.putExtra("name", googleAccount.displayName)

                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
                finish()

                // Use the authenticated account to sign in to the Drive service.
//                val credential = GoogleAccountCredential.usingOAuth2(
//                    this, setOf(DriveScopes.DRIVE_FILE)
//                )
//                credential.selectedAccount = googleAccount.account
//                val googleDriveService = Drive.Builder(
//                    AndroidHttp.newCompatibleTransport(),
//                    GsonFactory(),
//                    credential
//                )
//                    .setApplicationName("Drive API Migration")
//                    .build()
            }
            .addOnFailureListener { exception: Exception? ->
                Log.e(
                    TAG,
                    "Unable to sign in.",
                    exception
                )
            }
    }
}